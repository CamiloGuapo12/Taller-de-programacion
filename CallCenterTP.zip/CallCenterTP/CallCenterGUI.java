import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CallCenterGUI {
    private JFrame frame;
    private JTextArea textArea;
    private JTextField personaField;
    private JTextField telefonoField;

    public CallCenterGUI() {
        // Configurar la ventana
        frame = new JFrame("Simulador de Call Center");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);
        frame.setLayout(new BorderLayout());

        // Área de texto para mostrar resultados
        textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(textArea);
        frame.add(scrollPane, BorderLayout.CENTER);

        // Panel para los campos de entrada y botón
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new FlowLayout());

        personaField = new JTextField(10);
        telefonoField = new JTextField(10);
        JButton callButton = new JButton("Iniciar Llamada");

        inputPanel.add(new JLabel("Nombre:"));
        inputPanel.add(personaField);
        inputPanel.add(new JLabel("Teléfono:"));
        inputPanel.add(telefonoField);
        inputPanel.add(callButton);

        frame.add(inputPanel, BorderLayout.SOUTH);

        // Acción del botón
        callButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                iniciarLlamada();
            }
        });

        // Hacer visible la ventana
        frame.setVisible(true);
    }

    private void iniciarLlamada() {
        String nombre = personaField.getText().trim();
        String telefono = telefonoField.getText().trim();

        if (nombre.isEmpty() || telefono.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Por favor, ingrese un nombre y un teléfono.");
            return;
        }

        // Validar formato de teléfono (ejemplo simple: solo dígitos)
        if (!telefono.matches("\\d+")) {
            JOptionPane.showMessageDialog(frame, "El número de teléfono debe contener solo dígitos.");
            return;
        }

        Persona persona = new Persona(nombre);
        Telefono telefonoObj = new Telefono(telefono);
        Llamada llamada = new Llamada(persona, telefonoObj, this); // Pasar la instancia de CallCenterGUI

        // Iniciar la llamada en un nuevo hilo
        new Thread(llamada).start();

        // Mostrar el resultado en el área de texto
        textArea.append("Llamada iniciada por " + nombre + " usando el teléfono: " + telefono + "\n");
        textArea.setCaretPosition(textArea.getDocument().getLength()); // Desplazar hacia abajo
    }

    public void notifyCallEnded(String message) {
        textArea.append(message + "\n");
        textArea.setCaretPosition(textArea.getDocument().getLength()); // Desplazar hacia abajo
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CallCenterGUI());
    }
}
