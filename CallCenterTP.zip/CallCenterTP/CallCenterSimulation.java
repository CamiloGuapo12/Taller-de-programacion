public class CallCenterSimulation {
    public static void main(String[] args) {
        
        CallCenterGUI gui = new CallCenterGUI();
    }
}
