import java.util.Random;

public class Llamada implements Runnable {
    private Persona persona;
    private Telefono telefono;
    private static final Random random = new Random();
    private CallCenterGUI callCenterGUI; // Referencia a la GUI

    public Llamada(Persona persona, Telefono telefono, CallCenterGUI callCenterGUI) {
        this.persona = persona;
        this.telefono = telefono;
        this.callCenterGUI = callCenterGUI;
    }

    @Override
    public void run() {
        // Generar un tiempo de duración aleatorio entre 1 y 5 segundos
        int duration = random.nextInt(5000) + 1000; // Duración entre 1000 ms (1 segundo) y 5000 ms (5 segundos)
        
        try {
            // Simular la llamada
            Thread.sleep(duration);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt(); // Restaurar el estado de interrupción
        }

        // Llamada terminada, notificar a la GUI
        String message = persona.getNombre() + " ha terminado la llamada usando el teléfono: " + telefono.getNumero();
        callCenterGUI.notifyCallEnded(message); // Notificar a la GUI
    }
}
