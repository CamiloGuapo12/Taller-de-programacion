import java.util.ArrayList;
import java.util.List;

// Clase Producto
class Producto {
    private String nombre;
    private double precio;

    public Producto(String nombre, double precio) {
        this.nombre = nombre;
        this.precio = precio;
    }

    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }
}

// Clase Cliente
class Cliente {
    private String nombre;
    private List<Producto> carrito;

    public Cliente(String nombre) {
        this.nombre = nombre;
        this.carrito = new ArrayList<>();
    }

    public void agregarProducto(Producto producto) {
        carrito.add(producto);
    }

    public List<Producto> getCarrito() {
        return carrito;
    }

    public String getNombre() {
        return nombre;
    }
}

// Clase Cajera
class Cajera {
    public void procesarCompra(Cliente cliente) {
        System.out.println("Cajera procesando la compra de " + cliente.getNombre());
        double total = 0;
        for (Producto producto : cliente.getCarrito()) {
            System.out.println("Producto: " + producto.getNombre() + " - Precio: $" + producto.getPrecio());
            total += producto.getPrecio();
        }
        System.out.println("Total a pagar: $" + total);
    }
}

// Clase principal para simular el proceso de cobro
public class Supermercado {
    public static void main(String[] args) {
        // Crear productos
        Producto producto1 = new Producto("Manzana", 0.50);
        Producto producto2 = new Producto("Leche", 1.20);
        Producto producto3 = new Producto("Pan", 1.00);

        // Crear cliente y agregar productos al carrito
        Cliente cliente1 = new Cliente("Oscar");
        cliente1.agregarProducto(producto1);
        cliente1.agregarProducto(producto2);
        cliente1.agregarProducto(producto3);

        // Crear cajera
        Cajera cajera = new Cajera();

        // Procesar la compra del cliente
        cajera.procesarCompra(cliente1);
    }
}
