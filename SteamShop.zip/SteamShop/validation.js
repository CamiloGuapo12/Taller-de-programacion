const form = document.getElementById('form')
const firstname_input = document.getElementById('firstname-input')
const email_input = document.getElementById('email-input')
const password_input = document.getElementById('password-input')
const repeat_password_input = document.getElementById('repeat-password-input')
const error_message = document.getElementById('error-message')
const adminEmail = "admin@arbopolis.com"; // Correo del administrador

form.addEventListener('submit', (e) => {
  let errors = []

  if (firstname_input) {
    // Si tenemos un input de nombre, entonces estamos en el registro
    errors = getSignupFormErrors(firstname_input.value, email_input.value, password_input.value, repeat_password_input.value)
  } else {
    // Si no tenemos un input de nombre, entonces estamos en el inicio de sesión
    errors = getLoginFormErrors(email_input.value, password_input.value)
  }

  if (errors.length > 0) {
    // Si hay algún error
    e.preventDefault()
    error_message.innerText = errors.join(". ")
  } else {
    // Si no hay errores, procedemos con el registro o inicio de sesión
    if (firstname_input) {
      // Registro: Guardar los datos en localStorage
      handleSignup(email_input.value, firstname_input.value, password_input.value)
    } else {
      // Inicio de sesión: Verificar las credenciales
      handleLogin(email_input.value, password_input.value)
    }
  }
})

function getSignupFormErrors(firstname, email, password, repeatPassword) {
  let errors = []

  if (firstname === '' || firstname == null) {
    errors.push('El nombre es obligatorio')
    firstname_input.parentElement.classList.add('incorrect')
  }
  if (email === '' || email == null) {
    errors.push('El correo electrónico es obligatorio')
    email_input.parentElement.classList.add('incorrect')
  }
  if (password === '' || password == null) {
    errors.push('La contraseña es obligatoria')
    password_input.parentElement.classList.add('incorrect')
  }
  if (password.length < 8) {
    errors.push('La contraseña debe tener al menos 8 caracteres')
    password_input.parentElement.classList.add('incorrect')
  }
  if (password !== repeatPassword) {
    errors.push('La contraseña no coincide con la contraseña repetida')
    password_input.parentElement.classList.add('incorrect')
    repeat_password_input.parentElement.classList.add('incorrect')
  }

  return errors;
}

function getLoginFormErrors(email, password) {
  let errors = []

  if (email === '' || email == null) {
    errors.push('El correo electrónico es obligatorio')
    email_input.parentElement.classList.add('incorrect')
  }
  if (password === '' || password == null) {
    errors.push('La contraseña es obligatoria')
    password_input.parentElement.classList.add('incorrect')
  }

  return errors;
}

function handleSignup(email, firstname, password) {
  // Verificar si el correo ya está registrado
  if (localStorage.getItem(email)) {
    error_message.innerText = "Este correo electrónico ya está registrado.";
    email_input.parentElement.classList.add('incorrect');
    return;
  }

  // Crear un objeto usuario y guardarlo en localStorage
  const user = {
    firstname: firstname,
    email: email,
    password: password
  };

  localStorage.setItem(email, JSON.stringify(user)); // Guardamos el usuario con el correo como clave

  // Redirigir a la página de inicio de sesión
  window.location.href = 'login.html';
}

function handleLogin(email, password) {
  const user = JSON.parse(localStorage.getItem(email));

  if (user && user.password === password) {
    // Si las credenciales son correctas
    localStorage.setItem('usuario', JSON.stringify(user)); // Guardar usuario actual en localStorage

    // Verificar si el usuario es el administrador
    if (email === adminEmail) {
      localStorage.setItem('isAdmin', true); // Guardar que el usuario es admin
    } else {
      localStorage.removeItem('isAdmin'); // Borrar el flag de administrador si no lo es
    }

    // Redirigir al index.html
    window.location.href = 'index.html';
  } else {
    // Si las credenciales son incorrectas, mostrar un mensaje de error
    error_message.innerText = 'Correo o contraseña incorrectos';
    email_input.parentElement.classList.add('incorrect');
    password_input.parentElement.classList.add('incorrect');
  }
}

const allInputs = [firstname_input, email_input, password_input, repeat_password_input].filter(input => input != null)

allInputs.forEach(input => {
  input.addEventListener('input', () => {
    if (input.parentElement.classList.contains('incorrect')) {
      input.parentElement.classList.remove('incorrect')
      error_message.innerText = ''
    }
  })
})
