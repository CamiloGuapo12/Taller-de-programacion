// Contador del carrito
let cartCount = 0;
let cart = [];

// Selecciona los botones de "Añadir al carrito"
const addToCartButtons = document.querySelectorAll('.btn-outline-dark');

// Selecciona el contador del carrito y el elemento del modal
const cartCounter = document.querySelector('.badge');
const cartItems = document.getElementById('cartItems');

// Agregar productos al carrito
addToCartButtons.forEach(button => {
    button.addEventListener('click', () => {
        const card = button.closest('.card');
        const productName = card.querySelector('h5').textContent;

        let selectedEdition = 'Edición única'; // Valor por defecto si no hay selección de edición
        let selectedPrice = card.querySelector('.price').textContent.trim(); // Precio por defecto

        // Verificar si el producto tiene un selector de ediciones
        const editionSelector = card.querySelector('.edition-selector');
        if (editionSelector) {
            // Si el producto tiene ediciones, actualizar la edición y el precio
            selectedEdition = editionSelector.options[editionSelector.selectedIndex].textContent;
            selectedPrice = `$${editionSelector.value}`;
        }

        // Añadir el producto al carrito
        cart.push({ name: productName, edition: selectedEdition, price: selectedPrice });

        // Actualizar el contador y el contenido del carrito
        cartCounter.textContent = cart.length;
        updateCartModal();
    });
});

// Función para actualizar el contenido del modal
function updateCartModal() {
    cartItems.innerHTML = ''; // Limpiar el contenido actual
    let total = 0; // Total de la compra

    cart.forEach((item, index) => {
        const listItem = document.createElement('li');
        listItem.classList.add('list-group-item', 'd-flex', 'justify-content-between', 'align-items-center');
        listItem.textContent = `${item.name} (${item.edition}) - ${item.price}`;
        const removeButton = document.createElement('button');
        removeButton.classList.add('btn', 'btn-sm', 'btn-danger');
        removeButton.textContent = 'Eliminar';
        removeButton.addEventListener('click', () => {
            removeFromCart(index);
        });
        listItem.appendChild(removeButton);
        cartItems.appendChild(listItem);
        total += parseFloat(item.price.replace('$', ''));
    });

    // Actualizar el total
    const totalDisplay = document.getElementById('checkoutTotal');
    totalDisplay.textContent = `$${total.toFixed(2)}`;
}

// Función para eliminar un producto del carrito
function removeFromCart(index) {
    cart.splice(index, 1); // Eliminar el producto del carrito
    cartCounter.textContent = cart.length; // Actualizar el contador
    updateCartModal(); // Actualizar el contenido del modal
}

// Mostrar el modal del carrito al hacer clic en el ícono del carrito
const cartButton = document.querySelector('.btn-outline-dark');
cartButton.addEventListener('click', (e) => {
    e.preventDefault(); // Evitar el envío del formulario
    const modal = new bootstrap.Modal(document.getElementById('cartModal'));
    modal.show();
});


// Actualizar el precio según la edición seleccionada
document.querySelectorAll('.edition-selector').forEach(selector => {
    selector.addEventListener('change', function () {
        const selectedPrice = this.value; // Obtener el precio de la edición seleccionada
        const priceContainer = this.closest('.card').querySelector('.price');
        priceContainer.textContent = `$${selectedPrice}`;
    });
});

// Botón de finalizar compra
const finalizePurchaseButton = document.querySelector('#cartModal .btn-primary');

finalizePurchaseButton.addEventListener('click', () => {
    // Guardar el carrito en localStorage
    localStorage.setItem('cart', JSON.stringify(cart));

    // Redirigir a la página de checkout
    window.location.href = 'checkout.html';
});





