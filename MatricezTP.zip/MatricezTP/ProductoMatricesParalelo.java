import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ProductoMatricesParalelo {
    
    // Clase que define la tarea para cada Thread
    static class MultiplicacionSubmatriz implements Callable<Void> {
        private int[][] A, B, resultado;
        private int inicioFila, finFila;

        public MultiplicacionSubmatriz(int[][] A, int[][] B, int[][] resultado, int inicioFila, int finFila) {
            this.A = A;
            this.B = B;
            this.resultado = resultado;
            this.inicioFila = inicioFila;
            this.finFila = finFila;
        }

        @Override
        public Void call() {
            int columnasA = A[0].length;
            int columnasB = B[0].length;

            for (int i = inicioFila; i < finFila; i++) {
                for (int j = 0; j < columnasB; j++) {
                    for (int k = 0; k < columnasA; k++) {
                        resultado[i][j] += A[i][k] * B[k][j];
                    }
                }
            }
            return null;
        }
    }

    // Función para multiplicar matrices en paralelo
    public static int[][] multiplicarMatricesParalelo(int[][] A, int[][] B, int numThreads) throws InterruptedException, ExecutionException {
        int filasA = A.length;
        int columnasB = B[0].length;
        int[][] resultado = new int[filasA][columnasB];

        ExecutorService executor = Executors.newFixedThreadPool(numThreads);
        List<Future<Void>> futures = new ArrayList<>();

        // Dividimos las filas entre los threads
        int chunkSize = filasA / numThreads;

        for (int i = 0; i < numThreads; i++) {
            int inicioFila = i * chunkSize;
            int finFila = (i == numThreads - 1) ? filasA : inicioFila + chunkSize;

            MultiplicacionSubmatriz tarea = new MultiplicacionSubmatriz(A, B, resultado, inicioFila, finFila);
            futures.add(executor.submit(tarea));
        }

        // Esperamos a que todas las tareas terminen
        for (Future<Void> future : futures) {
            future.get();
        }

        executor.shutdown();
        return resultado;
    }

    // Función para llenar una matriz con valores aleatorios
    public static int[][] generarMatriz(int filas, int columnas) {
        int[][] matriz = new int[filas][columnas];
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                matriz[i][j] = (int) (Math.random() * 10); // Números entre 0 y 9
            }
        }
        return matriz;
    }

    // Main para medir el tiempo de ejecución con 4 Threads
    public static void main(String[] args) throws InterruptedException, ExecutionException {
        int tamaño = 1000; // Tamaño de las matrices
        int[][] A = generarMatriz(tamaño, tamaño);
        int[][] B = generarMatriz(tamaño, tamaño);

        long inicioParalelo = System.currentTimeMillis(); // Medir tiempo en paralelo
        int[][] resultadoParalelo = multiplicarMatricesParalelo(A, B, 4);
        long finParalelo = System.currentTimeMillis();

        System.out.println("Tiempo de ejecución con 4 Threads: " + (finParalelo - inicioParalelo) + " ms");
    }
}
