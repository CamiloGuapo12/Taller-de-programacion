public class ProductoMatricesSecuencial {
    
    // Función para multiplicar dos matrices secuencialmente
    public static int[][] multiplicarMatricesSecuencial(int[][] A, int[][] B) {
        int filasA = A.length;
        int columnasA = A[0].length;
        int columnasB = B[0].length;
        int[][] resultado = new int[filasA][columnasB];

        for (int i = 0; i < filasA; i++) {
            for (int j = 0; j < columnasB; j++) {
                for (int k = 0; k < columnasA; k++) {
                    resultado[i][j] += A[i][k] * B[k][j];
                }
            }
        }
        return resultado;
    }

    // Función para llenar una matriz con valores aleatorios
    public static int[][] generarMatriz(int filas, int columnas) {
        int[][] matriz = new int[filas][columnas];
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                matriz[i][j] = (int) (Math.random() * 10); // Números entre 0 y 9
            }
        }
        return matriz;
    }

    // Main para medir el tiempo de ejecución
    public static void main(String[] args) {
        int tamaño = 1000; // Tamaño de las matrices
        int[][] A = generarMatriz(tamaño, tamaño);
        int[][] B = generarMatriz(tamaño, tamaño);

        long inicio = System.currentTimeMillis(); // Medir el tiempo
        int[][] resultadoSecuencial = multiplicarMatricesSecuencial(A, B);
        long fin = System.currentTimeMillis();

        System.out.println("Tiempo de ejecución secuencial: " + (fin - inicio) + " ms");
    }
}
