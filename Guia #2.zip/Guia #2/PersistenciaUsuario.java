import java.io.*;
import java.util.List;

public class PersistenciaUsuario {

    public static void guardarUsuariosEnArchivo(List<Usuario> usuarios, String nombreArchivo) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(nombreArchivo, true))) {
            for (Usuario usuario : usuarios) {
                oos.writeObject(usuario);
            }
        }
    }

    @SuppressWarnings("unchecked")
    public static List<Usuario> cargarUsuariosDesdeArchivo(String nombreArchivo) throws IOException, ClassNotFoundException {
        List<Usuario> usuarios = new ArrayList<>();
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(nombreArchivo))) {
            while (true) {
                try {
                    Usuario usuario = (Usuario) ois.readObject();
                    usuarios.add(usuario);
                } catch (EOFException eof) {
                    break;
                }
            }
        }
        return usuarios;
    }
}
