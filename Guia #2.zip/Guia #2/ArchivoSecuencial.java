import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ArchivoSecuencial {

    public static void guardarUsuariosEnArchivoSecuencial(List<Usuario> usuarios, String nombreArchivo) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(nombreArchivo, true))) {
            for (Usuario usuario : usuarios) {
                oos.writeObject(usuario);
            }
        }
    }

    public static List<Usuario> cargarUsuariosDesdeArchivoSecuencial(String nombreArchivo) throws IOException, ClassNotFoundException {
        List<Usuario> usuarios = new ArrayList<>();
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(nombreArchivo))) {
            while (true) {
                try {
                    Usuario usuario = (Usuario) ois.readObject();
                    usuarios.add(usuario);
                } catch (EOFException eof) {
                    break;
                }
            }
        }
        return usuarios;
    }
}
