import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Date;

public class ArchivoAleatorio {

    public static void agregarUsuarioEnArchivoAleatorio(Usuario usuario, String nombreArchivo) throws IOException {
        try (RandomAccessFile raf = new RandomAccessFile(nombreArchivo, "rw")) {
            long fileLength = raf.length();
            raf.seek(fileLength);
            raf.writeInt(usuario.getUsuarioId());
            raf.writeUTF(usuario.getNombre());
            raf.writeUTF(usuario.getEmail());
            raf.writeLong(usuario.getFechaRegistro().getTime());
        }
    }

    public static Usuario leerUsuarioDesdeArchivoAleatorio(String nombreArchivo, long posicion) throws IOException {
        try (RandomAccessFile raf = new RandomAccessFile(nombreArchivo, "r")) {
            raf.seek(posicion);
            int usuarioId = raf.readInt();
            String nombre = raf.readUTF();
            String email = raf.readUTF();
            long fechaRegistroMillis = raf.readLong();
            Date fechaRegistro = new Date(fechaRegistroMillis);
            return new Usuario(usuarioId, nombre, email, fechaRegistro);
        }
    }
}
