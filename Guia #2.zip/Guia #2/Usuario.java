import java.io.Serializable;
import java.util.Date;

public class Usuario implements Serializable {
    private int usuarioId;
    private String nombre;
    private String email;
    private Date fechaRegistro;

    public Usuario(int usuarioId, String nombre, String email, Date fechaRegistro) {
        this.usuarioId = usuarioId;
        this.nombre = nombre;
        this.email = email;
        this.fechaRegistro = fechaRegistro;
    }

    public int getUsuarioId() {
        return usuarioId;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEmail() {
        return email;
    }

    public Date getFechaRegistro() {
        return fechaRegistro;
    }

    @Override
    public String toString() {
        return "Usuario{" +
                "usuarioId=" + usuarioId +
                ", nombre='" + nombre + '\'' +
                ", email='" + email + '\'' +
                ", fechaRegistro=" + fechaRegistro +
                '}';
    }
}