import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Usuario> usuarios = new ArrayList<>();

        // Captura de datos del usuario
        System.out.print("¿Cuántos usuarios deseas agregar? ");
        int numeroDeUsuarios = scanner.nextInt();
        scanner.nextLine();  // Limpiar el buffer

        for (int i = 0; i < numeroDeUsuarios; i++) {
            System.out.println("Ingrese los datos del usuario " + (i + 1) + ":");

            System.out.print("ID del Usuario: ");
            int id = scanner.nextInt();
            scanner.nextLine();  // Limpiar el buffer

            System.out.print("Nombre del Usuario: ");
            String nombre = scanner.nextLine();

            System.out.print("Email del Usuario: ");
            String email = scanner.nextLine();

            Date fechaRegistro = new Date();  // Captura la fecha actual como fecha de registro

            usuarios.add(new Usuario(id, nombre, email, fechaRegistro));
        }

        String nombreArchivoSecuencial = "usuarios_secuencial.dat";
        String nombreArchivoAleatorio = "usuarios_aleatorio.dat";

        // Guardar en archivo secuencial
        try {
            ArchivoSecuencial.guardarUsuariosEnArchivoSecuencial(usuarios, nombreArchivoSecuencial);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Leer del archivo secuencial
        List<Usuario> usuariosLeidos = null;
        try {
            usuariosLeidos = ArchivoSecuencial.cargarUsuariosDesdeArchivoSecuencial(nombreArchivoSecuencial);
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        if (usuariosLeidos != null) {
            System.out.println("Usuarios leídos del archivo secuencial:");
            for (Usuario usuario : usuariosLeidos) {
                System.out.println(usuario);
            }
        }

        // Agregar usuarios en archivo aleatorio y luego leer
        try {
            for (Usuario usuario : usuarios) {
                ArchivoAleatorio.agregarUsuarioEnArchivoAleatorio(usuario, nombreArchivoAleatorio);
            }

            // Leer un usuario específico desde archivo aleatorio
            long posicion = 0; // Lee el primer usuario
            Usuario usuarioLeido = ArchivoAleatorio.leerUsuarioDesdeArchivoAleatorio(nombreArchivoAleatorio, posicion);
            System.out.println("Usuario leído desde archivo aleatorio:");
            System.out.println(usuarioLeido);

        } catch (IOException e) {
            e.printStackTrace();
        }

        scanner.close();
    }
}
