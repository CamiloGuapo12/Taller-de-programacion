import java.util.Date;
import java.util.List;

public class RegistroUsuario {

    public static void registrarUsuario(List<Usuario> usuarios, int usuarioId, String nombre, String email, Date fechaRegistro) {
        Usuario usuario = new Usuario(usuarioId, nombre, email, fechaRegistro);
        usuarios.add(usuario);
    }
}
