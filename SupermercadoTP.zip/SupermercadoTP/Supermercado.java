import java.util.ArrayList;
import java.util.List;
import java.util.Random;

// Clase Producto
class Producto {
    private String nombre;
    private double precio;

    public Producto(String nombre, double precio) {
        this.nombre = nombre;
        this.precio = precio;
    }

    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }
}

// Clase Cliente
class Cliente {
    private String nombre;
    private List<Producto> carrito;

    public Cliente(String nombre) {
        this.nombre = nombre;
        this.carrito = new ArrayList<>();
    }

    public void agregarProducto(Producto producto) {
        carrito.add(producto);
    }

    public List<Producto> getCarrito() {
        return carrito;
    }

    public String getNombre() {
        return nombre;
    }
}

// Clase Cajera implementando Runnable para usar threads
class Cajera implements Runnable {
    private Cliente cliente;

    public Cajera(Cliente cliente) {
        this.cliente = cliente;
    }

    @Override
    public void run() {
        procesarCompra(cliente);
    }

    public void procesarCompra(Cliente cliente) {
        System.out.println("Cajera procesando la compra de " + cliente.getNombre());
        double total = 0;
        for (Producto producto : cliente.getCarrito()) {
            System.out.println(Thread.currentThread().getName() + " - Producto: " + producto.getNombre() + " - Precio: $" + producto.getPrecio());
            total += producto.getPrecio();
            try {
                // Simulamos el tiempo que tarda en escanear un producto
                Thread.sleep(1000); 
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        System.out.println("Total a pagar por " + cliente.getNombre() + ": $" + total);
        System.out.println(Thread.currentThread().getName() + " ha terminado de procesar a " + cliente.getNombre());
    }
}

// Clase principal para simular el proceso de cobro en un supermercado usando threads
public class Supermercado {
    private static final String[] nombresProductos = {"Manzana", "Leche", "Pan", "Huevos", "Cereal", "Carne", "Queso", "Jugo"};
    private static final double[] preciosProductos = {0.50, 1.20, 1.00, 2.00, 3.50, 5.00, 2.50, 1.80};
    private static final Random random = new Random();

    public static void main(String[] args) {
        // Crear varios clientes
        Cliente cliente1 = new Cliente("Oscar");
        Cliente cliente2 = new Cliente("Ana");
        Cliente cliente3 = new Cliente("Luis");

        // Llenar el carrito de los clientes con productos aleatorios
        llenarCarritoConProductosRandom(cliente1);
        llenarCarritoConProductosRandom(cliente2);
        llenarCarritoConProductosRandom(cliente3);

        // Crear cajeras para cada cliente (hilos)
        Thread cajera1 = new Thread(new Cajera(cliente1), "Cajera 1");
        Thread cajera2 = new Thread(new Cajera(cliente2), "Cajera 2");
        Thread cajera3 = new Thread(new Cajera(cliente3), "Cajera 3");

        // Iniciar el procesamiento de los clientes
        cajera1.start();
        cajera2.start();
        cajera3.start();
    }

    // Método para llenar el carrito con productos aleatorios
    private static void llenarCarritoConProductosRandom(Cliente cliente) {
        int cantidadProductos = random.nextInt(5) + 1; // Número de productos entre 1 y 5
        for (int i = 0; i < cantidadProductos; i++) {
            int indiceProducto = random.nextInt(nombresProductos.length);
            Producto producto = new Producto(nombresProductos[indiceProducto], preciosProductos[indiceProducto]);
            cliente.agregarProducto(producto);
        }
    }
}
