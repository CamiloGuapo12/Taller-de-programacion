import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.Random;

// Clase Productor
class Productor implements Runnable {
    private BlockingQueue<Integer> queue;
    private Random random;

    public Productor(BlockingQueue<Integer> queue) {
        this.queue = queue;
        this.random = new Random();
    }

    @Override
    public void run() {
        while (true) {
            try {
                // Genera un número aleatorio entre 1 y 100
                int numero = random.nextInt(100) + 1;
                System.out.println("Productor generó: " + numero);
                // Coloca el número en la cola
                queue.put(numero);
                // Simulamos el tiempo que tarda en generar un número
                Thread.sleep(500);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }
}

// Clase Consumidor
class Consumidor implements Runnable {
    private BlockingQueue<Integer> queue;

    public Consumidor(BlockingQueue<Integer> queue) {
        this.queue = queue;
    }

    @Override
    public void run() {
        while (true) {
            try {
                // Toma el número de la cola
                int numero = queue.take();
                // Multiplica el número por 2
                int resultado = numero * 2;
                System.out.println("Consumidor procesó: " + numero + " * 2 = " + resultado);
                // Simulamos el tiempo que tarda en procesar el número
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }
}

// Clase principal
public class ProductorConsumidor {
    public static void main(String[] args) {
        // Creamos una cola bloqueante con capacidad de 10 elementos
        BlockingQueue<Integer> queue = new ArrayBlockingQueue<>(10);

        // Creamos los hilos productor y consumidor
        Thread productorThread = new Thread(new Productor(queue), "Productor");
        Thread consumidorThread = new Thread(new Consumidor(queue), "Consumidor");

        // Iniciamos los hilos
        productorThread.start();
        consumidorThread.start();
    }
}
